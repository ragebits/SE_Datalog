# ESP32-WROVER-E / ESP32-WROVER-IE 
Kicad Footprint for ESP32-WROVER-E and ESP32-WROVER-IE

The footprint has been designed based on recommended pcb land pattern by EspressIf.

![alt text](https://github.com/kaevee/ESP32-WROVER-E/blob/main/Images/Recommended_PCB_Land_Pattern.png?raw=true)
